To Compile The following Program:

    For chunk Approach:
        Use following Command:
            g++ Assgn2_Chunk_Src-CS22BTECH11022.cpp
            ./a.out

    For Mixed Approach:
        Use following Command:
            g++ Assgn2_Mixed_Src-CS22BTECH11022.cpp
            ./a.out        

Output:

    For chunk Approach:
        Ouptut : out_chunk.txt
    
    For Mixed Approach:
        Ouptut : out_mixed.txt    