#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#define SIZE 4096

int isTetra(int num)
{
    int n = 1;
    while ((n * (n + 1) * (n + 2)) / 6 < num)
    {
        n++;
    }
    return (n * (n + 1) * (n + 2)) / 6 == num;
}

int main()
{
    clock_t start_time = clock();
    int temp;
    int n;
    int k;
    int i = 0;
    FILE *file = fopen("input.txt", "r");
    while (fscanf(file, "%d", &temp) == 1)
    {
        if (i == 0)
        {
            n = temp;
        }
        else
            k = temp;

        // printf("Read Integer: %d\n", temp);
        i++;
    }
    //printf("%d\n", n);
    //printf("%d\n", k);
    fclose(file);

    const char a[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    char * arr[]={"OutMain.log","OutFile1.log","OutFile2.log","OutFile3.log","OutFile4.log","OutFile5.log","OutFile6.log","OutFile7.log","OutFile8.log","OutFile9.log","OutFile10.log","OutFile11.log","OutFile12.log","OutFile13.log","OutFile14.log","OutFile15.log","OutFile16.log","OutFile17.log","OutFile18.log","OutFile19.log","OutFile20.log","OutFile21.log","OutFile22.log","OutFile23.log", "OutFile24.log","OutFile25.log", "OutFile26.log"};
    int shm_fd[k];
    int *ptr[k];
    for (int i = 0; i < k; i++)
    {
        ptr[i] = NULL;
    }
    
    int x = 1;
    int y = (int)(n / k);
    int z = y;
    for (int i = 0; i < k; i++)
    {
        shm_fd[i] = shm_open(&a[i], O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
        int tempVar = shm_fd[i];
        ftruncate(tempVar, SIZE);
        ptr[i] = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, tempVar, 0);

        pid_t pid;
        pid = fork();

        if (pid == 0)
        {
            FILE * file2 = fopen(arr[i+1], "w");
            FILE * tempFile = file2;
            int count = 0;
            int *temp = ptr[i];
            ptr[i] = ptr[i] + sizeof(int);
            //printf("x %d y %d\n", x, y);
            for (int j = x; j <= y /*&&*j <= n*/; j++)
            {
                if (isTetra(j))
                {
                    count++;
                    (*ptr[i]) = j;
                    // printf("In process: %d number: %d is tetra\n", i+1, (*ptr));
                    fprintf(tempFile,"%d : a tetrahedral number\n", (*ptr[i]));
                    ptr[i] = ptr[i] + sizeof(int);
                } //(*ptr) = 5;
                else
                {
                    // printf("In process: %d number: %d is not tetra\n", i+1, j);
                    fprintf(tempFile,"%d : Not a  tetrahedral number\n", j);
                }
            }
            (*temp) = count;
            fclose(tempFile);
            //printf("count : %d\n", count);
            munmap(ptr[i], SIZE);
            exit(EXIT_SUCCESS);
        }
        else
        {
            // parent process
            wait(NULL);
            x = y + 1;
            y = z * (i+2);
            if (x > n)
            {
                break;
            }
        }
    }

    FILE * file3 = fopen("OutMain.log", "w");
    for (int i = 0; i < k; i++)
    {
        if (ptr[i]==NULL)
        {
            fprintf(file3,"P%d:\n", i + 1);
            break;
        }
        
        int count = *ptr[i];
        ptr[i] = ptr[i] + sizeof(int);
        fprintf(file3,"P%d:", i + 1);
        for (int j = 0; j < count; j++)
        {
            fprintf(file3,"%d ", (*ptr[i]));
            ptr[i] = ptr[i] + sizeof(int);
        }

        int tempVar2 = shm_fd[i];
        munmap(ptr[i], SIZE);
        close(tempVar2);
        shm_unlink(&a[i]);
        fprintf(file3,"\n");
    }
    fclose(file3);
    clock_t end_time = clock();
    double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    //printf("Execution time: %.8f seconds\n", elapsed_time);
    return 0;
}