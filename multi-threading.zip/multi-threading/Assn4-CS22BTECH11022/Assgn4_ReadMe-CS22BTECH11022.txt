To execute the program, 

Please enter the inputs into "inp-params.txt" 
inputs should be integer values for number of writer threads, number of reader threads, number of tries for writer thread and reader threads  and time for critical section and time for remainder section respectively .

To run the program for general solution readers-writer problem, use following command in linux terminal:
    g++ rw-CS22BTECH11022.cpp
To execute the program, use following command in linux terminal:
    ./a.out
The outputs for general solution will be given in:
    1.RW-log.txt
    2.Average_time.txt


To run the program for fair solution to readers-writer problem, use following command in linux terminal:
    g++ frw-CS22BTECH11022.cpp
To execute the program, use following command in linux terminal:
    ./a.out    
The outputs for fair solution will be given in:
    1.FRW-log.txt
    2.FRWAverage_time.txt
