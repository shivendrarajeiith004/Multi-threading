#include <iostream>
#include <thread>
#include <mutex>
#include <semaphore.h>
#include <unistd.h> 
#include <stdio.h>
#include <chrono>
#include <fstream>
#include <random>
using namespace std;

random_device rd;
mt19937 gen(rd());
exponential_distribution<double> crit_sec_time; // exponential distribution for CS
exponential_distribution<double> remain_sec_time;
std::chrono::microseconds avg_write(0);
std::chrono::microseconds avg_read(0);
// Global variables
int readers = 0;
int writers = 0;
int randCSTime;
int randRemTime;
sem_t readers_mutex, writers_mutex, try_read_sem, Res_sem, printf_sem;
int k_w, k_r; // Number of requests each reader and writer makes
ofstream output("Average_time.txt");
ofstream outputFile("RW-log.txt");

// Function to simulate getting system time
string getSysTime()
{
    auto now = std::chrono::system_clock::now();
    std::time_t now_time_t = std::chrono::system_clock::to_time_t(now);
    std::tm now_tm = *std::localtime(&now_time_t);
    int hours = now_tm.tm_hour;
    int minutes = now_tm.tm_min;
    int seconds = now_tm.tm_sec;

    std::string timeString = std::to_string(hours) + ":" + std::to_string(minutes) + ":" + std::to_string(seconds);
    return timeString;
}

// Reader function
void reader(int thread_num)
{
    for (int i = 0; i < k_r; ++i) {
        string reqTime = getSysTime();
        // printf_semf("Reader %d is making request to enter critical section at time %s", thread_num, getSysTime());
        sem_wait(&printf_sem);
        auto start_time =chrono::high_resolution_clock::now();
        outputFile << "Reader " << thread_num << " is making request to enter critical section at time " << reqTime << endl;
        sem_post(&printf_sem);
        sem_wait(&try_read_sem);    // reader is trying to enter
        sem_wait(&readers_mutex);     // Lock section 
        readers++;           
        if (readers == 1)    
            sem_wait(&Res_sem); 
        sem_post(&readers_mutex);     // Release section 
        sem_post(&try_read_sem);    

        // Reading is performed
        // printf_semf("Reader %d is reading critical section at time %s", thread_num, getSysTime());
        sem_wait(&printf_sem);
        auto end_time =chrono::high_resolution_clock::now();
        outputFile << "Reader " << thread_num << " is reading critical section at time " << 
        getSysTime() << endl;
        sem_post(&printf_sem);
        this_thread::sleep_for(std::chrono::milliseconds((int)crit_sec_time(gen)));
         // Simulating reading time

        sem_wait(&readers_mutex);     
        readers--;           
        if (readers == 0)    
            sem_post(&Res_sem); //release the lock 
        sem_post(&readers_mutex);     // exit section 
        sem_wait(&printf_sem);
        outputFile << "Reader " << thread_num << " is leaving critical section at time " << 
        getSysTime() << endl;
        auto total_time = chrono::duration_cast<std::chrono::microseconds>(end_time -start_time);
        avg_read+= total_time; 
        output<< "Reader " << thread_num << " time " << 
        avg_read.count()<< endl;
        sem_post(&printf_sem);

        //sleep(1);
        this_thread::sleep_for(std::chrono::milliseconds((int)remain_sec_time(gen)));
        // printf_semf("Reader %d is leaving critical section at time %s", thread_num, getSysTime());
    }
}

// Writer function
void writer(int thread_num)
{
    for (int i = 0; i < k_w; ++i) {
        string reqTime = getSysTime();
        sem_wait(&printf_sem);
        auto start_time =chrono::high_resolution_clock::now();
        outputFile << "Writer " << thread_num << " is making request to enter critical section at time " << reqTime << endl;
        sem_post(&printf_sem);
        // printf_semf("Writer %d is making request to enter critical section at time %s", thread_num, getSysTime());
        sem_wait(&writers_mutex);     // Reserve entry section 
        writers++;          
        if (writers == 1)   
            sem_wait(&try_read_sem); //  lock the readers 
        sem_post(&writers_mutex);     // unlock entry section
        sem_wait(&Res_sem);   // 

        // Writing is performed
        sem_wait(&printf_sem);
        auto end_time =chrono::high_resolution_clock::now();
        outputFile << "Writer " << thread_num << " is writing in critical section at time " << 
        getSysTime() << endl;
        
        sem_post(&printf_sem);
        // printf_semf("Writer %d is writing in critical section at time %s", thread_num, getSysTime());
        sleep(1); // Simulating writing time
        this_thread::sleep_for(std::chrono::milliseconds((int)crit_sec_time(gen)));
        sem_post(&Res_sem); // Release Res_sem

        sem_wait(&writers_mutex);     // Reserve exit section
        writers--;           
        if (writers == 0)   
            sem_post(&try_read_sem); // unlock the readers. 
        sem_post(&writers_mutex);     // unlock exit section
        sem_wait(&printf_sem);
        outputFile << "Writer " << thread_num << " is leaving critical section at time " << 
        getSysTime() << endl;
        auto total_time = chrono::duration_cast<std::chrono::microseconds>(end_time -start_time);
        avg_write += total_time;
        output<< "Writer " << thread_num << " time " << 
        avg_write.count()<< endl;
        sem_post(&printf_sem);
        this_thread::sleep_for(std::chrono::milliseconds((int)remain_sec_time(gen)));
        // printf_semf("Writer %d is leaving critical section at time %s", thread_num, getSysTime());
    }
}

int main()
{
    // Initialize semaphores
    sem_init(&readers_mutex, 0, 1);
    sem_init(&writers_mutex, 0, 1);
    sem_init(&try_read_sem, 0, 1);
    sem_init(&Res_sem, 0, 1);
    sem_init(&printf_sem, 0, 1);

    ifstream inputFile("inp-params.txt");
    int n_w, n_r; 

    // Read the inputs from the file
    if (!(inputFile >> n_w >> n_r >> k_w >> k_r >>randCSTime >> randRemTime)) {
        std::cerr << "Error reading input from file\n";
        return 1;
    }
    
    inputFile.close();
    crit_sec_time = exponential_distribution<double>(1.0/randCSTime);
    remain_sec_time = exponential_distribution<double>(1.0/randRemTime);
    // Create threads
    thread readers[n_r], writers[n_w];
    for (int i = 0; i < n_w; ++i)
        writers[i] = thread(writer, i + 1);
    for (int i = 0; i < n_r; ++i)
        readers[i] = thread(reader, i + 1);

    // Join threads
    for (int i = 0; i < n_r; ++i)
        readers[i].join();
    for (int i = 0; i < n_w; ++i)
        writers[i].join();
    output <<"reader time : " <<avg_read.count()/n_r<<" microseconds"<<endl;
    output <<"writer time : " <<avg_write.count()/n_w<<" microseconds"<<endl;
    outputFile.close();
    // Destroy semaphores
    sem_destroy(&readers_mutex);
    sem_destroy(&writers_mutex);
    sem_destroy(&try_read_sem);
    sem_destroy(&Res_sem);
    sem_destroy(&printf_sem);
    return 0;
}
