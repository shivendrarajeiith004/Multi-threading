#include <iostream>
#include <fstream>
#include <cmath>
#include <thread>
#include <chrono>
#include <pthread.h>
#include <vector>
#include <cstring>
#include <sched.h>

using namespace std;
/*Function To Execute Chunk Method*/
void chunkThreadFunction(int **A, int **M, int rowStart, int rowEnd, int size)
{

    // rowStart == starting Row and rowEnd == Row in which Execution should stop

    for (int k = rowStart; k < rowEnd; k++)
    {
        // Standard code for matrix multiplication per Row
        for (int j = 0; j < size; j++)
        {
            int sum = 0;
            for (int i = 0; i < size; i++)
            {
                sum += A[k][i] * A[i][j];
            }
            M[k][j] = sum;
        }
    }
}

int main()
{
    // Input and Output files for each Threading Method
    ifstream inputFile("inp.txt");
    ofstream outputFileChunk("out_chunk.txt");

    // To check whether File is open or Not. Not mandatory but useful
    if (!outputFileChunk.is_open())
    {
        cerr << "Error opening the file!" << endl;
        return 1;
    }
    if (!inputFile.is_open())
    {
        cerr << "Error opening the file!" << endl;
        return 1;
    }

    // initialising the requiredd variables

    int number;
    int count = 0;
    int numberOfRows;
    int numberOfThreads;
    int numberOfCores;
    int boundedThreads;
    int i = 0;
    int *rowOrderMatrix;

    // Reading input from a File(inp.txt)
    while (inputFile >> number)
    {

        if (count == 0)
        {
            numberOfRows = number;

            rowOrderMatrix = new int[(int)pow(numberOfRows, 2)];
            count++;
        }
        else if (count == 1)
        {
            numberOfThreads = number;
            count++;
        }
        else if (count == 2)
        {
            numberOfCores = number;
            count++;
        }
        else if (count == 3)
        {
            boundedThreads = number;
            count++;
        }
        else
        {
            // count++;
            rowOrderMatrix[i] = number;
            i++;
        }

        // cout << "Read integer: " << number << std::endl;
    }

    // cout << "Number of Rows: " << numberOfRows << " Number of Threads: " << numberOfThreads << endl;

    inputFile.close();

    // initialising matrix = Actual 2D matrix, and matrix for Each Threading Method and Threads to Execute the matrix multiplication

    int size = numberOfRows;
    int **matrix;
    int **chunkMultMatrix;
    std::vector<std::thread> threads;

    // Allocating Memory to The matrices
    matrix = new int *[numberOfRows];
    chunkMultMatrix = new int *[numberOfRows];

    for (int i = 0; i < numberOfRows; i++)
    {
        matrix[i] = new int[numberOfRows];
        chunkMultMatrix[i] = new int[numberOfRows];
    }
    // creating a 2D matrix from a row order MAtrix
    int k = 0;
    for (int i = 0; i < numberOfRows; i++)
    {
        for (int j = 0; j < numberOfRows; j++)
        {
            matrix[i][j] = rowOrderMatrix[k];
            k++;
        }
    }

    delete[] rowOrderMatrix;
    // To Calculate Time required for Chunk method
    auto chunk_start_time = chrono::high_resolution_clock::now();
    int rowStart = 0;
    int temp = (numberOfRows / numberOfThreads);
    int rowEnd = rowStart + temp;

    // Dividing Rows of matrix for each thread using Chunk method
    for (int i = 0; i < numberOfThreads; i++)
    {
        if (i == numberOfThreads - 1)
        {
            rowEnd = size;
        }

        threads.emplace_back(chunkThreadFunction, matrix, chunkMultMatrix, rowStart, rowEnd, size);

        if (i < boundedThreads)
        {
            int coreId = i % numberOfCores;

            // Setting  thread affinity to the specified core
            cpu_set_t cpuset;
            CPU_ZERO(&cpuset);
            CPU_SET(coreId, &cpuset);

            
            int result = pthread_setaffinity_np(threads[i].native_handle(), sizeof(cpu_set_t), &cpuset);

            if (result != 0)
            {
                cerr << "Failed to set thread affinity." << endl;
                // error
            }
            else
            {
                //cout << "Thread " << i << " core " << coreId << endl;
            }
        }
        rowStart = rowEnd;
        rowEnd = rowStart + temp;
    }
    // joining All threads to main Thread
    for (int i = 0; i < numberOfThreads; ++i)
    {
        threads[i].join();
    }

    auto chunk_end_time = std::chrono::high_resolution_clock::now();

    auto chunk_time = chrono::duration_cast<std::chrono::microseconds>(chunk_end_time - chunk_start_time);

    // Outputting the code to each indivisual File
    outputFileChunk << " Chunk Multiplication matrix:" << endl;
    outputFileChunk << "Time taken: " << chunk_time.count() << " microseconds." << endl;
    outputFileChunk << "" << endl;
    for (int i = 0; i < numberOfRows; i++)
    {
        for (int j = 0; j < numberOfRows; j++)
        {
            outputFileChunk << " " << chunkMultMatrix[i][j];
        }
        outputFileChunk << "" << endl;
    }
    return 0;
}
