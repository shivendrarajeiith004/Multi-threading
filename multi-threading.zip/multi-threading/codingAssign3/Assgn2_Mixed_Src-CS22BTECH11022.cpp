#include <iostream>
#include <fstream>
#include <cmath>
#include <thread>
#include <chrono>
#include <pthread.h>
#include <vector>
#include <cstring>
#include <sched.h>

using namespace std;
// Function to execute Mixed Method
void mixedThreadFunction(int **A, int **M, int rowStart, int size, int nThreads, int threadId)
{
    // cout << "hello world !"<< endl;
    // for (int k = rowStart; k < size; 2*nThreads + k)
    
    //  kth row is where execution for matrix multiplication starts
    int k = rowStart;
    int i = 0;

    while (k < size)
    {

        // cout << "hello world !"<<k<<""<< endl;
        
        // standard code for matrix multiplication
        for (int j = 0; j < size; j++)
        {
            int sum = 0;
            for (int i = 0; i < size; i++)
            {
                sum += A[k][i] * A[i][j];
            }
            M[k][j] = sum;
        }
        
        // k should be incremented by formula k= threadId + i*nThreads given in question
        
        k = threadId + i * nThreads;
        i++;
    }
}

int main()
{
    // Input and Output files for each Threading Method
    ifstream inputFile("inp.txt");

    ofstream outputFileMixed("out_mixed.txt");

    // To check whether File is open or Not. Not mandatory but useful
    if (!outputFileMixed.is_open())
    {
        cerr << "Error opening the file!" << endl;
        return 1;
    }
    if (!inputFile.is_open())
    {
        cerr << "Error opening the file!" << endl;
        return 1;
    }
    
    // initialising the requiredd variables
    int number;
    int count = 0;
    int numberOfRows;
    int numberOfThreads;
    int numberOfCores;
    int boundedThreads;
    int i = 0;
    int *rowOrderMatrix;

    // Reading input from a File(inp.txt)
    
    while (inputFile >> number)
    {

        if (count == 0)
        {
            numberOfRows = number;

            rowOrderMatrix = new int[(int)pow(numberOfRows, 2)];
            count++;
        }
        else if (count == 1)
        {
            numberOfThreads = number;
            count++;
        }
        else if (count == 2)
        {
            numberOfCores = number;
            count++;
        }
        else if (count == 3)
        {
            boundedThreads = number;
            count++;
        }
        else
        {
            // count++;
            rowOrderMatrix[i] = number;
            i++;
        }

        // cout << "Read integer: " << number << std::endl;
    
    }

    // cout << "Number of Rows: " << numberOfRows << " Number of Threads: " << numberOfThreads << endl;

    inputFile.close();

    // initialising matrix = Actual 2D matrix, and matrix for Each Threading Method and Threads to Execute the matrix multiplication

    int size = numberOfRows;
    int **matrix;

    int **mixedMultMatrix;

    
    std::vector<std::thread> mixedThreads;

    // Allocating Memory to The matrices
    
    matrix = new int *[numberOfRows];

    mixedMultMatrix = new int *[numberOfRows];

    for (int i = 0; i < numberOfRows; i++)
    {
        matrix[i] = new int[numberOfRows];

        mixedMultMatrix[i] = new int[numberOfRows];
    }
    // creating a 2D matrix from a row order MAtrix
    int k = 0;
    for (int i = 0; i < numberOfRows; i++)
    {
        for (int j = 0; j < numberOfRows; j++)
        {
            matrix[i][j] = rowOrderMatrix[k];
            k++;
        }
    }

    delete[] rowOrderMatrix;

    // Dividing Rows of matrix for each thread using mixed method
    auto mixed_start_time = chrono::high_resolution_clock::now();

    for (int i = 0; i < numberOfThreads; i++)
    {
        
        mixedThreads.emplace_back(mixedThreadFunction, matrix, mixedMultMatrix, i, size, numberOfThreads, (i + 1));
        if (i < boundedThreads)
        {
            int coreId = i % numberOfCores;

            // Set thread affinity to the specified core
            cpu_set_t cpuset;
            CPU_ZERO(&cpuset);
            CPU_SET(coreId, &cpuset);

            int result = pthread_setaffinity_np(mixedThreads[i].native_handle(), sizeof(cpu_set_t), &cpuset);

            if (result != 0)
            {
                cerr << "Failed to set thread affinity." << endl;
                // error 
            }
            else
            {
                //cout << "Thread " << i << " core " << coreId << endl;
            }
        }
    }
    
    // joining All threads to main Thread
    
    for (int i = 0; i < numberOfThreads; ++i)
    {
        mixedThreads[i].join();
    }

    auto mixed_end_time = chrono::high_resolution_clock::now();

    // Calculating Time Taken To execute Each method of matrix multiplication

    auto mixed_time = chrono::duration_cast<std::chrono::microseconds>(mixed_end_time - mixed_start_time);

    // Outputting the code to each indivisual File
    
    outputFileMixed << " Mixed Multiplication matrix:" << endl;
    outputFileMixed << "Time taken: " << mixed_time.count() << " microseconds." << endl;
    outputFileMixed << "" << endl;
    for (int i = 0; i < numberOfRows; i++)
    {
        for (int j = 0; j < numberOfRows; j++)
        {
            outputFileMixed << " " << mixedMultMatrix[i][j];
        }
        outputFileMixed << "" << endl;
    }
    return 0;
}