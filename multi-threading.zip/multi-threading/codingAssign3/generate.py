import random

def generate_random_numbers(n):
    numbers = []
    for _ in range(n):
        row = []
        for _ in range(n):
            row.append(str(random.randint(1, 100)))
        numbers.append(row)
    return numbers

n = int(input("Enter the value of n: "))
k = int(input("Enter the value of k: "))
rowInc = int(input("Enter the value of rowInc: "))

random_numbers = generate_random_numbers(n)

with open("inp.txt", "w") as file:
    file.write(str(n) + "\n")
    file.write(str(k) + "\n")
    file.write(str(rowInc) + "\n")
    
    for row in random_numbers:
        file.write(" ".join(row) + "\n")

print("Numbers written to inp.txt")
